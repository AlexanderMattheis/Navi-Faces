type: static
friction: 100
size: 150
